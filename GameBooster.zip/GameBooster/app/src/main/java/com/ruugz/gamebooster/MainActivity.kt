package com.ruugz.gamebooster

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var reco: TextView
    private lateinit var btnFilter: Button
    private lateinit var btnVoice: Button
    private lateinit var seek: SeekBar

    private var style = 1
    private var filterIdx = 0

    private val filterNames = arrayOf("Hangat (cerah)", "Dingin", "Hijau (nyaman di mata)", "Retro", "Redup")
    private val filterColors = intArrayOf(
        Color.rgb(255, 170, 60), Color.rgb(60, 140, 255), Color.rgb(60, 200, 120),
        Color.rgb(190, 130, 70), Color.rgb(0, 0, 0)
    )
    private val voiceNames = arrayOf(
        "Normal", "Anak-anak (tinggi)", "Wanita (agak tinggi)", "Pria berat", "Monster (sangat rendah)"
    )
    private val voicePitch = floatArrayOf(1.0f, 1.5f, 1.25f, 0.8f, 0.6f)

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun lp() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(8) }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        layoutParams = lp()
        setOnClickListener {
            onClick()
            refresh()
            postDelayed({ refresh() }, 400)
        }
    }

    private fun label(t: String, size: Float = 14f) = TextView(this).apply {
        text = t
        textSize = size
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun spinner(items: Array<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = onSel(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(label("Game Booster", 24f))
        status = TextView(this)
        root.addView(status)

        // ---- Mode game
        root.addView(btn("MODE GAME ON + buka Free Fire") {
            toast(Booster.enable(this))
            val i = Booster.gameIntent(this)
            if (i == null) toast("Free Fire tidak ditemukan") else startActivity(i)
        })
        root.addView(btn("Matikan mode game (kembalikan pengaturan)") {
            Booster.disable(this)
            toast("Pengaturan dikembalikan")
        })
        root.addView(btn("Beri izin Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        root.addView(btn("Salin perintah ADB (izin animasi, opsional)") {
            val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("adb", cmd))
            toast("Disalin")
        })

        // ---- Filter layar
        root.addView(label("Filter layar (lapisan warna)", 18f))
        root.addView(spinner(filterNames, 0) { filterIdx = it; if (FilterService.active) sendFilter() })
        seek = SeekBar(this).apply {
            max = 100
            progress = 40
            layoutParams = lp()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && FilterService.active) sendFilter()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(TextView(this).apply { text = "Intensitas:" })
        root.addView(seek)
        btnFilter = btn("") { toggleFilter() }
        root.addView(btnFilter)

        // ---- Pengubah suara
        root.addView(label("Pengubah suara (live)", 18f))
        root.addView(spinner(voiceNames, 0) { VoiceService.pitch = voicePitch[it] })
        btnVoice = btn("") { toggleVoice() }
        root.addView(btnVoice)
        root.addView(TextView(this).apply {
            text = "Wajib pakai headset/earphone supaya tidak bergema. Suara baru terdengar di headset; " +
                "aplikasi lain (game, Discord, telepon) tetap memakai mikrofon asli."
            textSize = 12f
        })

        // ---- Rekomendasi
        root.addView(label("Rekomendasi setelan (isi manual di dalam game)", 18f))
        root.addView(spinner(arrayOf("Agresif (rush / jarak dekat)", "Seimbang", "Presisi (jarak jauh)"), 1) {
            style = it
            renderReco()
        })
        reco = TextView(this).apply { setTextIsSelectable(true); setPadding(0, dp(8), 0, 0) }
        root.addView(reco)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---- Filter
    private fun sendFilter() {
        startForegroundService(
            Intent(this, FilterService::class.java)
                .putExtra("color", filterColors[filterIdx])
                .putExtra("alpha", seek.progress)
        )
    }

    private fun toggleFilter() {
        if (FilterService.active) {
            stopService(Intent(this, FilterService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            toast("Izinkan 'tampil di atas aplikasi lain', lalu ketuk lagi")
        } else {
            sendFilter()
        }
    }

    // ---- Suara
    private fun toggleVoice() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java))
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
        } else {
            startForegroundService(Intent(this, VoiceService::class.java))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startForegroundService(Intent(this, VoiceService::class.java))
            refresh()
        }
    }

    private fun refresh() {
        status.text = buildString {
            appendLine("RAM kosong: ${Booster.freeRamMb(this@MainActivity)} MB dari ${Booster.totalRamMb(this@MainActivity)} MB")
            appendLine("Mode game: " + if (Booster.isOn(this@MainActivity)) "ON" else "off")
            appendLine("Izin Jangan Ganggu: " + if (Booster.hasDnd(this@MainActivity)) "ada" else "belum")
            append("Izin animasi (ADB): " + if (Booster.canSecure(this@MainActivity)) "ada" else "belum (opsional)")
        }
        btnFilter.text = if (FilterService.active) "Filter layar: matikan" else "Filter layar: aktifkan"
        btnVoice.text = if (VoiceService.running) "Pengubah suara: matikan" else "Pengubah suara: mulai"
        renderReco()
    }

    private fun renderReco() {
        val ram = Booster.totalRamMb(this)
        val dm = resources.displayMetrics
        val w = dm.widthPixels / dm.xdpi
        val h = dm.heightPixels / dm.ydpi
        val inch = sqrt(w * w + h * h)

        val graphics = when {
            ram < 3500 -> "RAM kecil: Grafis Lancar (Smooth), FPS tertinggi yang tersedia, bayangan mati, tekstur HD mati."
            ram < 6500 -> "RAM sedang: Grafis Lancar atau Standar, FPS Tinggi, bayangan mati."
            else -> "RAM besar: Grafis Standar/Tinggi, FPS Tinggi/Maksimal."
        }
        val base = when (style) {
            0 -> intArrayOf(95, 90, 85, 80, 50, 90)
            2 -> intArrayOf(70, 65, 60, 55, 35, 70)
            else -> intArrayOf(85, 80, 75, 70, 45, 80)
        }
        val adj = if (inch < 6.0) 5 else if (inch > 6.7) -5 else 0
        val v = base.map { (it + adj).coerceIn(1, 100) }

        reco.text = """
Grafis dalam game:
$graphics

Sensitivitas (titik awal):
Umum: ${v[0]}
Red Dot: ${v[1]}
Scope 2x: ${v[2]}
Scope 4x: ${v[3]}
AWM: ${v[4]}
Free Look: ${v[5]}

Layar terdeteksi ±${"%.1f".format(inch)} inci. Nilai ini hanya patokan awal, sesuaikan sendiri di Training Ground. Aplikasi ini tidak mengubah apa pun di dalam game; semua setelan diisi manual lewat menu Setelan game.
""".trimIndent()
    }
}
