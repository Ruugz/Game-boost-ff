package com.ruugz.gamebooster

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.os.Build
import android.os.IBinder

/**
 * Mikrofon -> ubah nada -> speaker/headset, langsung (live).
 * Hanya berlaku di dalam aplikasi ini, tidak mengubah mikrofon untuk aplikasi lain.
 */
class VoiceService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var pitch = 1.0f
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notif.build(this, "Pengubah suara aktif (pakai headset)")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(4, n)
        }
        if (!running) {
            running = true
            Thread { loop() }.start()
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        val rate = 16000
        var rec: AudioRecord? = null
        var track: AudioTrack? = null
        try {
            val minRec = AudioRecord.getMinBufferSize(
                rate, android.media.AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val minPlay = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minRec * 2
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) return

            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minPlay * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val buf = ShortArray(1024)
            rec.startRecording()
            track.play()
            var applied = -1f
            while (running) {
                if (pitch != applied) {
                    try {
                        track.playbackParams = PlaybackParams().setSpeed(1f).setPitch(pitch)
                    } catch (_: Exception) {}
                    applied = pitch
                }
                val r = rec.read(buf, 0, buf.size)
                if (r > 0) track.write(buf, 0, r)
            }
        } catch (_: Exception) {
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { track?.stop() } catch (_: Exception) {}
            try { track?.release() } catch (_: Exception) {}
            running = false
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
