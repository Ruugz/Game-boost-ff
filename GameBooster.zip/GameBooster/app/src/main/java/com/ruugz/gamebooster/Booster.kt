package com.ruugz.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings

/** Optimasi tingkat sistem saja. Tidak menyentuh file/memori game. */
object Booster {
    val GAMES = listOf("com.dts.freefiremax", "com.dts.freefireth")

    private val ANIM = listOf(
        Settings.Global.WINDOW_ANIMATION_SCALE,
        Settings.Global.TRANSITION_ANIMATION_SCALE,
        Settings.Global.ANIMATOR_DURATION_SCALE
    )

    fun canSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") ==
            PackageManager.PERMISSION_GRANTED

    fun hasDnd(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    private fun memInfo(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi
    }

    fun freeRamMb(ctx: Context): Long = memInfo(ctx).availMem shr 20
    fun totalRamMb(ctx: Context): Long = memInfo(ctx).totalMem shr 20

    fun gameIntent(ctx: Context): Intent? =
        GAMES.firstNotNullOfOrNull { ctx.packageManager.getLaunchIntentForPackage(it) }

    private fun killBackground(ctx: Context): Int {
        val am = ctx.getSystemService(ActivityManager::class.java)
        var n = 0
        for (a in ctx.packageManager.getInstalledApplications(0)) {
            if ((a.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if (a.packageName == ctx.packageName || a.packageName in GAMES) continue
            am.killBackgroundProcesses(a.packageName)
            n++
        }
        return n
    }

    fun enable(ctx: Context): String {
        val p = ctx.getSharedPreferences("gb", Context.MODE_PRIVATE)
        val r = ctx.contentResolver
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val notes = mutableListOf<String>()

        if (!p.getBoolean("on", false)) {
            val ed = p.edit()
            if (canSecure(ctx)) ANIM.forEach { ed.putFloat(it, Settings.Global.getFloat(r, it, 1f)) }
            if (hasDnd(ctx)) ed.putInt("dnd", nm.currentInterruptionFilter)
            ed.putBoolean("on", true).apply()
        }

        if (canSecure(ctx)) {
            try {
                ANIM.forEach { Settings.Global.putFloat(r, it, 0f) }
                notes += "Animasi sistem dimatikan"
            } catch (ex: Exception) {
                notes += "Animasi gagal diubah"
            }
        } else {
            notes += "Animasi dilewati (izin WRITE_SECURE_SETTINGS belum ada)"
        }

        if (hasDnd(ctx)) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            notes += "Jangan Ganggu aktif (kontak prioritas tetap masuk)"
        } else {
            notes += "Jangan Ganggu dilewati (izin belum diberikan)"
        }

        notes += "Menutup ${killBackground(ctx)} aplikasi latar belakang"
        return notes.joinToString("\n")
    }

    fun disable(ctx: Context) {
        val p = ctx.getSharedPreferences("gb", Context.MODE_PRIVATE)
        if (!p.getBoolean("on", false)) return
        val r = ctx.contentResolver
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (canSecure(ctx)) {
            try {
                ANIM.forEach { if (p.contains(it)) Settings.Global.putFloat(r, it, p.getFloat(it, 1f)) }
            } catch (_: Exception) {}
        }
        if (p.contains("dnd") && hasDnd(ctx)) {
            nm.setInterruptionFilter(p.getInt("dnd", NotificationManager.INTERRUPTION_FILTER_ALL))
        }
        p.edit().clear().apply()
    }

    fun isOn(ctx: Context): Boolean =
        ctx.getSharedPreferences("gb", Context.MODE_PRIVATE).getBoolean("on", false)
}
