package com.ruugz.gamebooster

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.View
import android.view.WindowManager

/** Lapisan warna tipis di atas layar (tembus sentuhan). Bukan pemrosesan gambar game. */
class FilterService : Service() {
    companion object {
        @Volatile var active = false
    }

    private var wm: WindowManager? = null
    private var overlay: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(3, Notif.build(this, "Filter layar aktif"))
        val color = intent?.getIntExtra("color", Color.rgb(255, 170, 60)) ?: Color.rgb(255, 170, 60)
        val pct = intent?.getIntExtra("alpha", 40) ?: 40

        if (overlay == null) {
            val w = getSystemService(WindowManager::class.java)
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            // Android 12+ memblokir sentuhan tembus bila opasitas jendela > 0.8
            lp.alpha = 0.8f
            w.addView(v, lp)
            wm = w
            overlay = v
        }
        val a = (pct * 0.55f * 2.55f).toInt().coerceIn(0, 255)
        overlay?.setBackgroundColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
        active = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
        active = false
        super.onDestroy()
    }
}
