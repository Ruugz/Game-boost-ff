# Game Booster
- Mode Game: tutup aplikasi latar, Jangan Ganggu, matikan animasi (tidak menyentuh file/memori game)
- Filter layar: lapisan warna tembus sentuhan di atas layar
- Pengubah suara live: mikrofon -> ubah nada -> headset (hanya di dalam aplikasi ini)
- Rekomendasi setelan dan sensitivitas Free Fire

Build: push ke GitHub -> tab Actions -> unduh artifact app-debug-apk.
